//
//  ViewController.swift
//  day2_ios
//
//  Created by MacStudent on 2018-02-21.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import UIKit

class loginVC: UIViewController {
    

    @IBOutlet weak var txtemail: UITextField!
    @IBOutlet weak var txtpwd: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


 
   
    @IBOutlet weak var loginaction: UINavigationItem!
    @IBAction func btnloginaction(_ sender: UIButton) {
        let email = txtemail.text
        let password = txtpwd.text
        
        if (email == "test" && password == "test"){
            let infoalert = UIAlertController(title: "login Successful", message : "You are authenticated" , preferredStyle: .alert)
            
            infoalert.addAction(UIAlertAction(title : "okay", style : .default, handler : nil))
            
            self.present(infoalert, animated: true, completion: nil)
        }
    }
    @IBOutlet weak var btnloginaction: UIBarButtonItem!
    
    
    @IBAction func btnregisteraction(_ sender: Any) {
        weak var btnregisteraction: UIBarButtonItem!
        let registersb : UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        
        
       let registerVC = registersb.instantiateViewController(withIdentifier: "RegistrationScreen")
        //self.present(registerVC, animated: true, completion: nil)
        navigationController?.pushViewController(registerVC, animated: true)
    }
}

