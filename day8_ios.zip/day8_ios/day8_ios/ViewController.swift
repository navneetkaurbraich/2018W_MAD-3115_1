//
//  ViewController.swift
//  day8_ios
//
//  Created by MacStudent on 2018-03-01.
//  Copyright © 2018 macstudent. All rights reserved.
//

import UIKit
import MapKit

class ViewController: UIViewController {
    

    @IBOutlet weak var mymap: MKMapView!
    let lambtonCollegeLocation = CLLocation(latitude: 43.773257, longitude: -79.335899)
    let regionRadius :CLLocationDistance = 500
    let locationManager = CLLocationManager()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        mymap.mapType = MKMapType.standard
       // centerMapOnLocation(location: lambtonCollegeLocation, title: "Lambton College", subTitle: "265 Yorkland Blvd")
        
        locationManager.delegate = self
        locationManager.desiredAccuracy = kCLLocationAccuracyBest
        locationManager.requestAlwaysAuthorization()
        locationManager.requestWhenInUseAuthorization()
        
        if
            (CLLocationManager.locationServicesEnabled()){
            locationManager.startUpdatingLocation()
        }
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func centerMapOnLocation(location: CLLocation,title:String, subTitle: String) {
        let coordinateRegion = MKCoordinateRegionMakeWithDistance(location.coordinate,regionRadius,regionRadius)
        
        mymap.setRegion(coordinateRegion, animated: true)
        let myAnnotation: MKPointAnnotation = MKPointAnnotation()
        myAnnotation.coordinate = CLLocationCoordinate2DMake(location.coordinate.latitude,location.coordinate.longitude)
        myAnnotation.title = title
        myAnnotation.coordinate = CLLocationCoordinate2DMake(location.coordinate.latitude,location.coordinate.longitude)
        myAnnotation.title = title
        myAnnotation.subtitle = subTitle
        mymap.addAnnotation(myAnnotation)
    }


}

extension ViewController:
CLLocationManagerDelegate{
    
    func locationManager(_ manager: CLLocationManager,didFailWithError error: Error){
        print("error:: \(error.localizedDescription)")
    }
    
    func locationManager(_ manager: CLLocationManager, didChangeAuthorization status: CLAuthorizationStatus) {
        if status == .authorizedWhenInUse {
            locationManager.requestLocation()
        }
    }
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        if locations.first != nil {
            print("location:: \(locations)")
        }
        
        centerMapOnLocation(location: locationManager.location!, title: "Current Location", subTitle: " ")
    }
}

