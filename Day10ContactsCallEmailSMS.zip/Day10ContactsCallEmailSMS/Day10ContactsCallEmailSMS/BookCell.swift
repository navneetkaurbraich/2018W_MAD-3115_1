//
//  BookCell.swift
//  Day10ContactsCallEmailSMS
//
//  Created by Jigisha Patel on 2018-03-02.
//  Copyright © 2018 JK. All rights reserved.
//

import UIKit

class BookCell: UICollectionViewCell {
    
    @IBOutlet var lblBookTitle: UILabel!
    @IBOutlet var imgBook: UIImageView!
}
